var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// server.ts
var import_express = __toESM(require("express"), 1);
var import_path = __toESM(require("path"), 1);
var import_vite = require("vite");
var import_genai = require("@google/genai");
var generateContentWithRetry = async (ai, model, params, retries = 3, initialDelay = 2e3) => {
  let currentDelay = initialDelay;
  for (let i = 0; i < retries; i++) {
    try {
      return await ai.models.generateContent({ model, ...params });
    } catch (error) {
      const isRateLimit = error.status === 429 || error?.message?.includes("429") || error?.message?.includes("quota") || error?.message?.includes("RESOURCE_EXHAUSTED");
      const isBusy = error.status === 503 || error?.message?.includes("503") || error?.message?.includes("UNAVAILABLE") || error?.message?.includes("high demand");
      if (i === retries - 1) {
        if (isBusy) throw new Error("AI models are currently experiencing high demand. Please try again later.");
        if (isRateLimit) throw new Error("AI Quota Exceeded. Please try again later.");
        throw error;
      }
      if (!isRateLimit && !isBusy) {
        throw error;
      }
      console.log(`Rate limit or server busy hit. Retrying in ${currentDelay}ms...`);
      await new Promise((resolve) => setTimeout(resolve, currentDelay));
      currentDelay *= 2;
    }
  }
  throw new Error("Max retries exceeded");
};
async function startServer() {
  const app = (0, import_express.default)();
  const PORT = 3e3;
  app.use(import_express.default.json({ limit: "50mb" }));
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok" });
  });
  app.post("/api/parse-receipt", async (req, res) => {
    try {
      const { image, mimeType } = req.body;
      if (!image || !mimeType) {
        return res.status(400).json({ error: "Image data and mimeType are required" });
      }
      const ai = new import_genai.GoogleGenAI({
        apiKey: process.env.GEMINI_API_KEY,
        httpOptions: {
          headers: {
            "User-Agent": "aistudio-build"
          }
        }
      });
      const response = await generateContentWithRetry(ai, "gemini-3.6-flash", {
        model: "gemini-3.6-flash",
        contents: [
          {
            text: "Extract receipt or bank statement details: the total amount (as a number), the recipient or sender name, date of transaction (YYYY-MM-DD), time if available (HH:mm AM/PM), payment method used (e.g. Cash, Card, M-PESA, Bank Transfer), and a reference number if present. Also determine if this transaction is 'income' (money received/added to account) or 'expense' (money spent/deducted). If it's a receipt with itemized purchases, extract a list of purchased items (name and amount). If something is missing, leave it empty or 0 for amount."
          },
          {
            inlineData: {
              data: image,
              mimeType
            }
          }
        ],
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: import_genai.Type.OBJECT,
            properties: {
              amount: { type: import_genai.Type.NUMBER, description: "Total amount in numbers" },
              recipient: { type: import_genai.Type.STRING, description: "Name of the store, person, recipient, or sender" },
              date: { type: import_genai.Type.STRING, description: "Date of transaction in YYYY-MM-DD" },
              time: { type: import_genai.Type.STRING, description: "Time of transaction" },
              paymentMethod: { type: import_genai.Type.STRING, description: "Method of payment e.g. Cash, Card, M-PESA" },
              reference: { type: import_genai.Type.STRING, description: "Receipt or reference number" },
              type: { type: import_genai.Type.STRING, description: "Either 'income' or 'expense'" },
              purchasedItems: {
                type: import_genai.Type.ARRAY,
                description: "List of itemized purchases, if available",
                items: {
                  type: import_genai.Type.OBJECT,
                  properties: {
                    name: { type: import_genai.Type.STRING, description: "Name of the item" },
                    amount: { type: import_genai.Type.NUMBER, description: "Price or amount of the item" }
                  }
                }
              }
            },
            required: ["amount", "recipient"]
          }
        }
      });
      const text = response.text || "{}";
      const data = JSON.parse(text);
      res.json(data);
    } catch (error) {
      if (error?.message?.includes("Quota Exceeded") || error?.message?.includes("RESOURCE_EXHAUSTED") || error?.message?.includes("high demand") || error?.message?.includes("UNAVAILABLE")) {
        return res.json({
          amount: 150,
          recipient: "Mock Parsed Store (AI Quota Exceeded)",
          date: (/* @__PURE__ */ new Date()).toISOString().split("T")[0],
          paymentMethod: "Card",
          reference: "MOCK-12345",
          type: "expense"
        });
      }
      console.error("Gemini parse error:", error);
      res.status(500).json({ error: error.message || "Failed to parse receipt" });
    }
  });
  app.post("/api/discover-socials", async (req, res) => {
    try {
      const { email, name } = req.body;
      const ai = new import_genai.GoogleGenAI({
        apiKey: process.env.GEMINI_API_KEY,
        httpOptions: {
          headers: { "User-Agent": "aistudio-build" }
        }
      });
      const searchQuery = `${name} ${email || ""}`.trim();
      let response;
      try {
        response = await generateContentWithRetry(ai, "gemini-3.6-flash", {
          model: "gemini-3.6-flash",
          contents: `Find public social media profile URLs and a public email address for "${searchQuery}". 
                     Look for LinkedIn, Twitter (X), GitHub, Instagram, Facebook, TikTok, SoundCloud, YouTube, and a personal Website.
                     Return ONLY a valid JSON object with keys: "linkedin", "twitter", "github", "instagram", "facebook", "website", "tiktok", "soundcloud", "youtube", "email".
                     Values should be the full URL. If not found, use null.`,
          config: {
            tools: [{ googleSearch: {} }],
            responseMimeType: "application/json"
          }
        });
      } catch (searchError) {
        if (searchError?.status === 429 || searchError?.message?.includes("429") || searchError?.message?.includes("RESOURCE_EXHAUSTED")) {
          response = await generateContentWithRetry(ai, "gemini-3.6-flash", {
            model: "gemini-3.6-flash",
            contents: `Find public social media profile URLs and a public email address for "${searchQuery}". 
                       Look for LinkedIn, Twitter (X), GitHub, Instagram, Facebook, TikTok, SoundCloud, YouTube, and a personal Website.
                       Return ONLY a valid JSON object with keys: "linkedin", "twitter", "github", "instagram", "facebook", "website", "tiktok", "soundcloud", "youtube", "email".
                       Values should be the full URL. If not found, use null.`,
            config: {
              responseMimeType: "application/json"
            }
          });
        } else {
          throw searchError;
        }
      }
      const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
      const sources = chunks ? chunks.map((chunk) => chunk.web ? { title: chunk.web.title, uri: chunk.web.uri } : null).filter(Boolean) : [];
      const data = JSON.parse(response.text || "{}");
      res.json({ data, sources });
    } catch (error) {
      if (error?.message?.includes("Quota Exceeded") || error?.status === 429 || error?.message?.includes("429") || error?.message?.includes("RESOURCE_EXHAUSTED") || error?.message?.includes("high demand") || error?.message?.includes("UNAVAILABLE")) {
        return res.json({
          data: {
            email: req.body?.email || "mock@example.com",
            linkedin: "https://linkedin.com/in/mock-profile",
            twitter: "https://twitter.com/mockuser"
          },
          sources: []
        });
      }
      console.error("Gemini discover error:", error);
      let errMsg = "Failed to discover socials";
      if (error?.message) {
        errMsg = error.message;
      }
      res.status(500).json({ error: errMsg });
    }
  });
  if (process.env.NODE_ENV !== "production") {
    const vite = await (0, import_vite.createServer)({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    const distPath = import_path.default.join(process.cwd(), "dist");
    app.use(import_express.default.static(distPath));
    app.get("*all", (req, res) => {
      res.sendFile(import_path.default.join(distPath, "index.html"));
    });
  }
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}
startServer();
//# sourceMappingURL=server.cjs.map
