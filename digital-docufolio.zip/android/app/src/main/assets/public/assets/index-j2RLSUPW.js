const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-CyrBcsxv.js","assets/index-D3Zdzgh7.js"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-D3Zdzgh7.js";const n=r("SplashScreen",{web:()=>t(()=>import("./web-CyrBcsxv.js"),__vite__mapDeps([0,1])).then(e=>new e.SplashScreenWeb)});export{n as SplashScreen};
