import{W as n}from"./index-D3Zdzgh7.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
