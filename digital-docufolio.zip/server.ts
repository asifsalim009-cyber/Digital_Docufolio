import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";

const generateContentWithRetry = async (ai, model, params, retries = 3, initialDelay = 2000) => {
  let currentDelay = initialDelay;
  for (let i = 0; i < retries; i++) {
    try {
      return await ai.models.generateContent({ model, ...params });
    } catch (error) {
      const isRateLimit = error.status === 429 || error?.message?.includes('429') || error?.message?.includes('quota') || error?.message?.includes('RESOURCE_EXHAUSTED');
      const isBusy = error.status === 503 || error?.message?.includes('503') || error?.message?.includes('UNAVAILABLE') || error?.message?.includes('high demand');
      
      if (i === retries - 1) {
        if (isBusy) throw new Error("AI models are currently experiencing high demand. Please try again later.");
        if (isRateLimit) throw new Error("AI Quota Exceeded. Please try again later.");
        throw error;
      }
      if (!isRateLimit && !isBusy) {
        throw error;
      }
      console.log(`Rate limit or server busy hit. Retrying in ${currentDelay}ms...`);
      await new Promise(resolve => setTimeout(resolve, currentDelay));
      currentDelay *= 2; // Exponential backoff
    }
  }
  throw new Error("Max retries exceeded");
};

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: "50mb" }));

  // API routes FIRST
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok" });
  });

  app.post("/api/parse-receipt", async (req, res) => {
    try {
      const { image, mimeType } = req.body;
      if (!image || !mimeType) {
        return res.status(400).json({ error: "Image data and mimeType are required" });
      }

      const ai = new GoogleGenAI({
        apiKey: process.env.GEMINI_API_KEY,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          }
        }
      });

      const response = await generateContentWithRetry(ai, 'gemini-3.6-flash', {
        model: "gemini-3.6-flash",
        contents: [
          {
            text: "Extract receipt or bank statement details: the total amount (as a number), the recipient or sender name, date of transaction (YYYY-MM-DD), time if available (HH:mm AM/PM), payment method used (e.g. Cash, Card, M-PESA, Bank Transfer), and a reference number if present. Also determine if this transaction is 'income' (money received/added to account) or 'expense' (money spent/deducted). If it's a receipt with itemized purchases, extract a list of purchased items (name and amount). If something is missing, leave it empty or 0 for amount."
          },
          {
            inlineData: {
              data: image,
              mimeType: mimeType
            }
          }
        ],
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              amount: { type: Type.NUMBER, description: "Total amount in numbers" },
              recipient: { type: Type.STRING, description: "Name of the store, person, recipient, or sender" },
              date: { type: Type.STRING, description: "Date of transaction in YYYY-MM-DD" },
              time: { type: Type.STRING, description: "Time of transaction" },
              paymentMethod: { type: Type.STRING, description: "Method of payment e.g. Cash, Card, M-PESA" },
              reference: { type: Type.STRING, description: "Receipt or reference number" },
              type: { type: Type.STRING, description: "Either 'income' or 'expense'" },
              purchasedItems: {
                type: Type.ARRAY,
                description: "List of itemized purchases, if available",
                items: {
                  type: Type.OBJECT,
                  properties: {
                    name: { type: Type.STRING, description: "Name of the item" },
                    amount: { type: Type.NUMBER, description: "Price or amount of the item" }
                  }
                }
              }
            },
            required: ["amount", "recipient"]
          }
        }
      });

      const text = response.text || "{}";
      const data = JSON.parse(text);
      res.json(data);
    } catch (error: any) {
      // Fallback for quota exceeded
      if (error?.message?.includes("Quota Exceeded") || error?.message?.includes("RESOURCE_EXHAUSTED") || error?.message?.includes("high demand") || error?.message?.includes("UNAVAILABLE")) {
         return res.json({
            amount: 150.00,
            recipient: "Mock Parsed Store (AI Quota Exceeded)",
            date: new Date().toISOString().split('T')[0],
            paymentMethod: "Card",
            reference: "MOCK-12345",
            type: "expense"
         });
      }
      console.error("Gemini parse error:", error);
      res.status(500).json({ error: error.message || "Failed to parse receipt" });
    }
  });

  app.post("/api/discover-socials", async (req, res) => {
    try {
      const { email, name } = req.body;
      const ai = new GoogleGenAI({
        apiKey: process.env.GEMINI_API_KEY,
        httpOptions: {
          headers: { 'User-Agent': 'aistudio-build' }
        }
      });
      
      const searchQuery = `${name} ${email || ''}`.trim();

      let response;
      try {
        response = await generateContentWithRetry(ai, 'gemini-3.6-flash', {
          model: 'gemini-3.6-flash',
          contents: `Find public social media profile URLs and a public email address for "${searchQuery}". 
                     Look for LinkedIn, Twitter (X), GitHub, Instagram, Facebook, TikTok, SoundCloud, YouTube, and a personal Website.
                     Return ONLY a valid JSON object with keys: "linkedin", "twitter", "github", "instagram", "facebook", "website", "tiktok", "soundcloud", "youtube", "email".
                     Values should be the full URL. If not found, use null.`,
          config: {
            tools: [{ googleSearch: {} }],
            responseMimeType: 'application/json'
          }
        });
      } catch (searchError: any) {
        if (searchError?.status === 429 || searchError?.message?.includes("429") || searchError?.message?.includes("RESOURCE_EXHAUSTED")) {
          // Fallback without search
          response = await generateContentWithRetry(ai, 'gemini-3.6-flash', {
            model: 'gemini-3.6-flash',
            contents: `Find public social media profile URLs and a public email address for "${searchQuery}". 
                       Look for LinkedIn, Twitter (X), GitHub, Instagram, Facebook, TikTok, SoundCloud, YouTube, and a personal Website.
                       Return ONLY a valid JSON object with keys: "linkedin", "twitter", "github", "instagram", "facebook", "website", "tiktok", "soundcloud", "youtube", "email".
                       Values should be the full URL. If not found, use null.`,
            config: {
              responseMimeType: 'application/json'
            }
          });
        } else {
          throw searchError;
        }
      }

      const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
      const sources = chunks
        ? chunks.map((chunk: any) => chunk.web ? { title: chunk.web.title, uri: chunk.web.uri } : null).filter(Boolean)
        : [];

      const data = JSON.parse(response.text || '{}');
      res.json({ data, sources });
    } catch (error: any) {
      if (error?.message?.includes("Quota Exceeded") || error?.status === 429 || error?.message?.includes("429") || error?.message?.includes("RESOURCE_EXHAUSTED") || error?.message?.includes("high demand") || error?.message?.includes("UNAVAILABLE")) {
        // Provide mock fallback
        return res.json({
            data: {
               email: req.body?.email || "mock@example.com",
               linkedin: "https://linkedin.com/in/mock-profile",
               twitter: "https://twitter.com/mockuser"
            },
            sources: []
        });
      }
      console.error("Gemini discover error:", error);
      let errMsg = "Failed to discover socials";
      if (error?.message) {
        errMsg = error.message;
      }
      res.status(500).json({ error: errMsg });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*all', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
